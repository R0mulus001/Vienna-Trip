plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.laur.milantrip"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.laur.milantrip"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "1.2"
    }

    signingConfigs {
        // Key lives in app/milan.p12, encrypted (AES-256). Its password is only in the
        // GitHub secret SIGNING_PASSWORD, so the key file is useless to anyone else.
        create("trip") {
            val pw = System.getenv("SIGNING_PASSWORD")
                ?: error("SIGNING_PASSWORD is not set (add it under repo Settings > Secrets and variables > Actions)")
            storeFile = file("milan.p12")
            storeType = "PKCS12"
            storePassword = pw
            keyAlias = "app"
            keyPassword = pw
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("trip")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("trip")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
