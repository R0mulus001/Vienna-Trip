# Milan Trip (Android)

Milan city guide with live GPS distance, day plans, food and aperitivo spots. Set your trip dates in the Day plans tab.

Built by GitHub Actions from `MilanTrip.zip` in the repo root (workflow "Build Milan APK").
Everything the app shows is in `app/src/main/assets/index.html`.
