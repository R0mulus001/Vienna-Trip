package com.laur.krakowtrip

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf

class MainActivity : ComponentActivity() {

    private lateinit var state: TripState
    private lateinit var photos: Photos
    private val gps = mutableStateOf<LatLng?>(null)
    private var lm: LocationManager? = null
    private var listening = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) = onFix(l)
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val askLocation = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) startLocation()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        val db = TripDb(applicationContext)
        state = TripState(db)
        photos = Photos(applicationContext, db)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        setContent { TripApp(state, photos, gps.value, ::openUrl) }
        if (!hasLocation()) askLocation.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    override fun onStart() { super.onStart(); startLocation() }
    override fun onStop() { super.onStop(); stopLocation() }

    private fun hasLocation() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        val m = lm ?: return
        if (listening || !hasLocation()) return
        listening = true
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter { runCatching { m.isProviderEnabled(it) }.getOrDefault(false) }
        providers.forEach { pr ->
            runCatching { m.getLastKnownLocation(pr) }.getOrNull()?.let { if (System.currentTimeMillis() - it.time < 10 * 60_000) onFix(it) }
            runCatching { m.requestLocationUpdates(pr, 15_000L, 20f, listener, mainLooper) }
        }
    }

    private fun stopLocation() {
        if (!listening) return
        listening = false
        runCatching { lm?.removeUpdates(listener) }
    }

    private fun onFix(l: Location) {
        val n = LatLng(l.latitude, l.longitude)
        val old = gps.value
        if (old == null || km(old.lat, old.lng, n.lat, n.lng) > 0.03) gps.value = n
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: ActivityNotFoundException) {}
    }
}
