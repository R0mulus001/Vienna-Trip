package com.laur.krakowtrip

// Trip data for Kraków: sights, day-plan themes, food and drink, prices.

data class Place(
    val id: String,
    val name: String,
    val lat: Double,
    val lng: Double,
    val min: Int = 0,
    val pri: Int = 2,
    val desc: String,
    val out: Boolean = false,
    val closed: List<Int> = emptyList(), // 0=Sun ... 6=Sat
    val kinds: List<String> = emptyList(), // coffee, lunch, dinner, bar
    val price: Int = 0,
) {
    val isFood get() = kinds.isNotEmpty()
}

data class Theme(val key: String, val name: String, val blurb: String, val stops: List<Place>)

data class Cost(val lo: Int, val hi: Int, val basis: String, val menu: List<Pair<String, Int>>)

private fun P(id: String, name: String, lat: Double, lng: Double, min: Int, pri: Int, desc: String, out: Boolean = false, closed: List<Int> = emptyList()) =
    Place(id, name, lat, lng, min, pri, desc, out, closed)

private fun F(id: String, name: String, lat: Double, lng: Double, kinds: List<String>, price: Int, desc: String) =
    Place(id, name, lat, lng, desc = desc, kinds = kinds, price = price)

object Trip {
    const val CITY = "Kraków"
    const val CITY_EN = "Krakow"
    const val TZ = "Europe/Warsaw"
    const val CUR = "zł"

    val THEMES: List<Theme> = listOf(
        Theme("city", "Old Town & Wawel", "Main Square to the castle", listOf(
            P("florian", "St Florian's Gate", 50.0654, 19.9414, 15, 2, "The last surviving medieval city gate, start of the Royal Route.", out = true),
            P("barbakan", "Barbican", 50.0656, 19.9418, 25, 3, "Round brick fortress outside the gate. Open in the warmer months."),
            P("rynek", "Main Square (Rynek Główny)", 50.0617, 19.9373, 30, 1, "One of Europe's largest medieval squares.", out = true),
            P("mariacki", "St Mary's Basilica", 50.0616, 19.9394, 40, 1, "Gothic church with Veit Stoss's carved altar. The bugle call plays from the tower every hour."),
            P("sukiennice", "Cloth Hall (Sukiennice)", 50.0616, 19.9372, 25, 1, "Renaissance market hall in the middle of the square, full of amber and souvenir stalls."),
            P("ratusz", "Town Hall Tower", 50.0614, 19.9358, 25, 3, "All that is left of the old town hall. Climb up for the view."),
            P("grodzka", "Grodzka Street", 50.0580, 19.9376, 20, 2, "The old road from the square down to Wawel, past churches and cafés.", out = true),
            P("wawel", "Wawel Hill & castle courtyard", 50.0541, 19.9352, 45, 1, "Royal castle on the hill. The grounds are free, the interiors need timed tickets.", out = true),
            P("wawelcat", "Wawel Cathedral", 50.0547, 19.9351, 50, 1, "Coronation church of Polish kings. Climb to the Sigismund Bell."),
            P("smok", "Dragon's Den & dragon statue", 50.0530, 19.9338, 20, 2, "Cave under Wawel (seasonal). The statue by the river breathes fire every few minutes.", out = true),
        )),
        Theme("art", "Museums", "Leonardo, Matejko, the square's underground", listOf(
            P("underground", "Rynek Underground", 50.0620, 19.9378, 75, 1, "Medieval Kraków excavated beneath the Main Square. Book a time slot."),
            P("czart", "Czartoryski Museum", 50.0640, 19.9407, 75, 1, "Home of Leonardo's Lady with an Ermine.", closed = listOf(1)),
            P("sukgal", "Sukiennice Gallery", 50.0617, 19.9369, 60, 2, "19th-century Polish painting upstairs in the Cloth Hall. Terrace with a square view.", closed = listOf(1)),
            P("colmaius", "Collegium Maius", 50.0617, 19.9335, 50, 2, "The university's oldest building, where Copernicus studied. Guided visits.", closed = listOf(0)),
            P("mnk", "National Museum (main building)", 50.0604, 19.9235, 90, 2, "Polish art, design and arms.", closed = listOf(1)),
            P("manggha", "Manggha Japanese art centre", 50.0509, 19.9303, 50, 3, "Japanese art across the river from Wawel.", closed = listOf(1)),
            P("mocak", "MOCAK contemporary art", 50.0473, 19.9611, 75, 2, "Contemporary art museum right next to Schindler's Factory.", closed = listOf(1)),
        )),
        Theme("jewish", "Kazimierz", "Synagogues, Plac Nowy, the river", listOf(
            P("szeroka", "Szeroka Street", 50.0518, 19.9476, 20, 1, "The broad old square at the heart of the Jewish quarter.", out = true),
            P("oldsyn", "Old Synagogue", 50.0512, 19.9487, 40, 2, "Poland's oldest surviving synagogue, now a museum."),
            P("remuh", "Remuh Synagogue & Cemetery", 50.0526, 19.9479, 30, 1, "Small working synagogue with an old cemetery behind it.", closed = listOf(6)),
            P("placnowy", "Plac Nowy", 50.0514, 19.9446, 30, 1, "Round market hall square. Get a zapiekanka from the hatches.", out = true),
            P("corpus", "Corpus Christi Basilica", 50.0498, 19.9441, 25, 2, "Huge Gothic church with a boat-shaped pulpit."),
            P("skalka", "Skałka church", 50.0479, 19.9378, 20, 3, "Pauline church by the river, crypt of famous Poles."),
            P("bernatek", "Father Bernatek footbridge", 50.0481, 19.9496, 15, 2, "Footbridge to Podgórze with floating acrobat sculptures.", out = true),
        )),
        Theme("war", "Podgórze & WWII", "Ghetto, Schindler, a mound", listOf(
            P("ghetto", "Ghetto Heroes Square", 50.0466, 19.9544, 15, 1, "Memorial of empty chairs where the ghetto was cleared.", out = true),
            P("apteka", "Pharmacy Under the Eagle", 50.0466, 19.9552, 40, 1, "The only pharmacy left inside the ghetto, now a museum."),
            P("wall", "Ghetto wall fragment", 50.0438, 19.9528, 10, 2, "Surviving piece of the wall, shaped like Jewish gravestones.", out = true),
            P("schindler", "Oskar Schindler's Factory", 50.0477, 19.9617, 120, 1, "Museum of Kraków under Nazi occupation. Book tickets ahead."),
            P("mocak", "MOCAK contemporary art", 50.0473, 19.9611, 60, 3, "Next door to the factory.", closed = listOf(1)),
            P("krakus", "Krakus Mound", 50.0381, 19.9583, 30, 2, "Prehistoric mound with a free view over the whole city.", out = true),
        )),
        Theme("green", "Mounds & green Kraków", "Parks, the river, big views", listOf(
            P("planty", "Planty park", 50.0634, 19.9325, 30, 1, "Green ring around the Old Town where the walls once stood.", out = true),
            P("bulwary", "Vistula boulevards", 50.0533, 19.9325, 30, 1, "Riverside walk under Wawel, with boats and deckchairs.", out = true),
            P("jordan", "Jordan Park", 50.0632, 19.9148, 25, 3, "Large park with statues of famous Poles.", out = true),
            P("blonia", "Błonia meadow", 50.0598, 19.9107, 20, 2, "Huge open meadow, perfect for a walk.", out = true),
            P("kosciuszko", "Kościuszko Mound", 50.0549, 19.8932, 60, 1, "Hilltop mound with the best panorama of Kraków. Small entry fee.", out = true),
            P("krakus", "Krakus Mound", 50.0381, 19.9583, 30, 2, "The other mound, free, south of the river.", out = true),
        )),
        Theme("beyond", "Day trips", "Salt mine, Nowa Huta, Auschwitz", listOf(
            P("wieliczka", "Wieliczka Salt Mine", 49.9833, 20.0552, 180, 1, "Chapels carved out of salt deep underground. Book a tour; train from the main station."),
            P("nowahuta", "Nowa Huta Central Square", 50.0718, 20.0376, 45, 2, "Communist-era model town with grand socialist-realist streets.", out = true),
            P("arka", "Lord's Ark Church", 50.0856, 20.0236, 25, 3, "Boat-shaped church built in defiance of the regime."),
            P("tyniec", "Tyniec Abbey", 50.0193, 19.8160, 60, 3, "Benedictine abbey on a cliff over the Vistula."),
            P("auschwitz", "Auschwitz-Birkenau Memorial", 50.0266, 19.2035, 240, 1, "About 70 km away. Entry needs a reserved pass, book weeks ahead."),
        )),
        Theme("free", "Free & outdoors", "Squares, gates, river", listOf(
            P("florian", "St Florian's Gate", 50.0654, 19.9414, 10, 2, "Medieval gate at the top of Floriańska Street.", out = true),
            P("rynek", "Main Square (Rynek Główny)", 50.0617, 19.9373, 30, 1, "Listen for the bugle call from St Mary's on the hour.", out = true),
            P("sukiennice", "Cloth Hall (Sukiennice)", 50.0616, 19.9372, 20, 1, "Walk through the market arcade."),
            P("grodzka", "Grodzka Street", 50.0580, 19.9376, 15, 2, "Down the old road to Wawel.", out = true),
            P("wawel", "Wawel Hill & castle courtyard", 50.0541, 19.9352, 40, 1, "Hill and courtyard are free to wander.", out = true),
            P("smok", "Dragon's Den & dragon statue", 50.0530, 19.9338, 10, 2, "Wait for the statue to breathe fire.", out = true),
            P("bulwary", "Vistula boulevards", 50.0533, 19.9325, 25, 1, "River walk under the castle.", out = true),
            P("szeroka", "Szeroka Street", 50.0518, 19.9476, 15, 1, "Heart of Kazimierz.", out = true),
            P("placnowy", "Plac Nowy", 50.0514, 19.9446, 20, 1, "Market square, busy at night.", out = true),
            P("bernatek", "Father Bernatek footbridge", 50.0481, 19.9496, 10, 2, "Cross to Podgórze.", out = true),
            P("ghetto", "Ghetto Heroes Square", 50.0466, 19.9544, 10, 1, "The empty chairs memorial.", out = true),
            P("krakus", "Krakus Mound", 50.0381, 19.9583, 30, 2, "Free city view at sunset.", out = true),
        )),
    )
    val THEME_MAP = THEMES.associateBy { it.key }
    val THEME_ORDER = listOf("free", "city", "jewish", "war", "art", "green", "beyond")
    val DEF_ORDER = listOf("city", "jewish", "war", "art", "green", "beyond", "free")

    val FOOD: List<Place> = listOf(
        F("noworolski", "Noworolski, Cloth Hall", 50.0617, 19.9371, listOf("coffee"), 3, "Art Nouveau café inside the Cloth Hall since 1910."),
        F("camelot", "Café Camelot", 50.0630, 19.9393, listOf("coffee", "lunch"), 2, "Cosy café with naive art on the walls. Good apple cake."),
        F("wedel", "Wedel chocolate lounge", 50.0614, 19.9378, listOf("coffee"), 2, "Hot chocolate on the Main Square."),
        F("charlotte", "Charlotte", 50.0641, 19.9352, listOf("coffee", "lunch"), 2, "French bakery-café on Plac Szczepański, great for breakfast."),
        F("massolit", "Massolit Books & Café", 50.0612, 19.9250, listOf("coffee"), 1, "Second-hand bookshop with cake and coffee."),
        F("goodlood", "Good Lood", 50.0495, 19.9444, listOf("coffee"), 1, "Ice cream with a queue, on Plac Wolnica in Kazimierz."),
        F("temida", "Bar Mleczny Pod Temidą", 50.0567, 19.9376, listOf("lunch"), 1, "Classic milk bar: cheap pierogi and soups, order at the counter."),
        F("przystanek", "Przystanek Pierogarnia", 50.0575, 19.9432, listOf("lunch", "dinner"), 1, "Tiny place serving only pierogi."),
        F("krakowiacy", "Pierogarnia Krakowiacy", 50.0627, 19.9345, listOf("lunch", "dinner"), 1, "Folk-style pierogi spot near the square."),
        F("endzior", "Zapiekanki at Plac Nowy", 50.0514, 19.9446, listOf("lunch", "dinner"), 1, "Long open-faced baguettes from the round market hall."),
        F("podwawelem", "Pod Wawelem", 50.0563, 19.9383, listOf("lunch", "dinner"), 2, "Huge Polish portions and beer by the metre."),
        F("morskieoko", "Morskie Oko", 50.0640, 19.9355, listOf("dinner"), 2, "Highlander food and live folk music."),
        F("starka", "Starka", 50.0502, 19.9431, listOf("dinner"), 2, "Polish dishes and house-made flavoured vodkas in Kazimierz."),
        F("hamsa", "Hamsa", 50.0515, 19.9473, listOf("lunch", "dinner"), 2, "Israeli food on Szeroka Street."),
        F("aniolami", "Pod Aniołami", 50.0563, 19.9375, listOf("dinner"), 3, "Grilled meats in a Gothic cellar on Grodzka."),
        F("wierzynek", "Wierzynek", 50.0609, 19.9385, listOf("dinner"), 3, "Historic restaurant on the Main Square, famous since a royal feast in 1364."),
        F("alchemia", "Alchemia", 50.0518, 19.9447, listOf("bar"), 1, "Candlelit Kazimierz bar, the classic of the area."),
        F("hevre", "Hevre", 50.0503, 19.9468, listOf("bar"), 1, "Bar in a former Jewish prayer house, with faded murals."),
        F("forum", "Forum Przestrzenie", 50.0498, 19.9347, listOf("bar"), 1, "Deckchairs by the river in an old communist hotel."),
        F("wodka", "Wódka Café Bar", 50.0612, 19.9418, listOf("bar"), 2, "Tasting flights of Polish vodka."),
        F("piwnica", "Piwnica pod Baranami", 50.0613, 19.9352, listOf("bar"), 2, "Legendary cellar bar and cabaret on the Main Square."),
    )

    private const val C = "coffee and something sweet"
    private const val M = "a main course and a drink"
    private const val B = "two drinks"
    val COST: Map<String, Cost> = mapOf(
        "noworolski" to Cost(35, 60, C, listOf("Coffee" to 18, "Hot chocolate" to 22, "Apple pie" to 22, "Cake" to 24)),
        "camelot" to Cost(30, 50, C, listOf("Coffee" to 14, "Apple cake" to 18, "Soup" to 20, "Breakfast" to 32)),
        "wedel" to Cost(25, 45, "hot chocolate or a dessert", listOf("Coffee" to 14, "Hot chocolate" to 24, "Chocolate dessert" to 28)),
        "charlotte" to Cost(30, 55, "breakfast or coffee and pastry", listOf("Croissant" to 10, "Coffee" to 14, "Bread with spreads" to 25, "Breakfast" to 38)),
        "massolit" to Cost(20, 35, C, listOf("Coffee" to 12, "Cake" to 16, "Cheesecake" to 18)),
        "goodlood" to Cost(10, 20, "ice cream", listOf("One scoop" to 9, "Two scoops" to 17)),
        "temida" to Cost(20, 35, "a soup and a main course", listOf("Żurek soup" to 9, "Pierogi" to 15, "Pork cutlet (schabowy)" to 20, "Compote" to 4)),
        "przystanek" to Cost(20, 35, "a plate of pierogi and a drink", listOf("Pierogi ruskie (8 pcs)" to 22, "Meat pierogi" to 24, "Sweet pierogi" to 22, "Drink" to 6)),
        "krakowiacy" to Cost(30, 50, M, listOf("Żurek soup" to 18, "Pierogi" to 28, "Pork cutlet (schabowy)" to 38, "Beer" to 14)),
        "endzior" to Cost(15, 25, "a zapiekanka and a drink", listOf("Classic zapiekanka" to 15, "Loaded zapiekanka" to 22, "Drink" to 6)),
        "podwawelem" to Cost(50, 80, M, listOf("Żurek soup" to 22, "Pierogi" to 30, "Roast pork knuckle" to 65, "Beer, 0.5 l" to 15)),
        "morskieoko" to Cost(55, 90, M, listOf("Grilled oscypek cheese" to 25, "Kwaśnica soup" to 22, "Roast pork knuckle" to 60, "Beer" to 15)),
        "starka" to Cost(60, 100, M, listOf("Żurek soup" to 24, "Pierogi" to 35, "Roast duck" to 65, "Flavoured vodka shot" to 12)),
        "hamsa" to Cost(50, 80, M, listOf("Hummus" to 30, "Shakshuka" to 38, "Falafel plate" to 40, "Lemonade" to 15)),
        "aniolami" to Cost(80, 140, M, listOf("Żurek soup" to 28, "Pierogi" to 38, "Grilled meat platter" to 85, "Glass of wine" to 25)),
        "wierzynek" to Cost(150, 250, M, listOf("Żurek soup" to 45, "Pierogi" to 55, "Roast duck" to 110, "Glass of wine" to 40)),
        "alchemia" to Cost(25, 45, B, listOf("Vodka shot" to 10, "Beer, 0.5 l" to 14, "Cocktail" to 25)),
        "hevre" to Cost(25, 45, B, listOf("Beer" to 14, "Cocktail" to 25, "Shakshuka" to 32)),
        "forum" to Cost(25, 45, B, listOf("Beer" to 15, "Cocktail" to 25, "Pizza" to 35)),
        "wodka" to Cost(30, 60, B, listOf("Single shot" to 10, "Beer" to 14, "Tasting flight, 6 shots" to 40)),
        "piwnica" to Cost(25, 45, B, listOf("Beer" to 14, "Glass of wine" to 20, "Cocktail" to 25)),
    )

    val FREE = setOf("florian", "rynek", "sukiennice", "grodzka", "wawel", "bulwary", "planty", "jordan", "blonia", "szeroka", "placnowy", "corpus", "skalka", "bernatek", "ghetto", "wall", "krakus", "nowahuta", "arka")
    private val CAT = mapOf(
        "underground" to "museum", "czart" to "museum", "sukgal" to "museum", "colmaius" to "museum", "mnk" to "museum", "manggha" to "museum", "mocak" to "museum",
        "schindler" to "museum", "apteka" to "museum", "oldsyn" to "museum", "wieliczka" to "museum", "auschwitz" to "museum",
        "planty" to "park", "bulwary" to "park", "jordan" to "park", "blonia" to "park", "kosciuszko" to "park", "krakus" to "park", "ratusz" to "park",
    )
    val CATLABEL = mapOf("sight" to "Sight", "museum" to "Museum", "park" to "Park & view", "food" to "Restaurant", "coffee" to "Café", "drinks" to "Bar")
    val PRICE = listOf("", "zł", "zł zł", "zł zł zł")

    val WIKI = mapOf(
        "florian" to "St._Florian's_Gate", "barbakan" to "Kraków_Barbican", "rynek" to "Main_Square,_Kraków", "mariacki" to "St._Mary's_Basilica,_Kraków",
        "sukiennice" to "Cloth_Hall,_Kraków", "ratusz" to "Town_Hall_Tower,_Kraków", "grodzka" to "Grodzka_Street", "wawel" to "Wawel_Castle",
        "wawelcat" to "Wawel_Cathedral", "smok" to "Wawel_Dragon", "underground" to "Rynek_Underground", "czart" to "Czartoryski_Museum",
        "sukgal" to "Sukiennice_Museum", "colmaius" to "Collegium_Maius", "mnk" to "National_Museum,_Kraków", "manggha" to "Manggha",
        "mocak" to "Museum_of_Contemporary_Art_in_Kraków", "szeroka" to "Szeroka_Street,_Kraków", "oldsyn" to "Old_Synagogue_(Kraków)",
        "remuh" to "Remah_Synagogue", "placnowy" to "Plac_Nowy", "corpus" to "Corpus_Christi_Basilica,_Kraków", "skalka" to "Skałka",
        "bernatek" to "Father_Bernatek_Footbridge", "ghetto" to "Ghetto_Heroes_Square", "apteka" to "Pharmacy_Under_the_Eagle", "wall" to "Kraków_Ghetto",
        "schindler" to "Oskar_Schindler's_Enamel_Factory", "krakus" to "Krakus_Mound", "planty" to "Planty_Park", "bulwary" to "Vistula_Boulevards",
        "jordan" to "Jordan_Park", "blonia" to "Błonia,_Kraków", "kosciuszko" to "Kościuszko_Mound", "wieliczka" to "Wieliczka_Salt_Mine",
        "nowahuta" to "Nowa_Huta", "arka" to "Lord's_Ark_Church", "tyniec" to "Tyniec_Abbey", "auschwitz" to "Auschwitz_concentration_camp",
    )
    val COMMONS = mapOf(
        "rynek" to "Rynek Główny Kraków", "sukiennice" to "Sukiennice Kraków", "mariacki" to "Kościół Mariacki Kraków", "wawel" to "Wawel Kraków zamek",
        "wawelcat" to "Katedra Wawelska", "smok" to "Smok Wawelski", "underground" to "Podziemia Rynku Kraków", "czart" to "Muzeum Książąt Czartoryskich",
        "schindler" to "Fabryka Schindlera Kraków", "placnowy" to "Plac Nowy Kraków", "szeroka" to "Ulica Szeroka Kraków", "bulwary" to "Bulwary Wiślane Kraków",
        "wieliczka" to "Kopalnia Soli Wieliczka", "nowahuta" to "Plac Centralny Nowa Huta",
    )

    val HOLIDAYS = mapOf(
        "01-01" to "New Year's Day", "01-06" to "Epiphany", "05-01" to "Labour Day", "05-03" to "Constitution Day", "08-15" to "Assumption Day",
        "11-01" to "All Saints' Day", "11-11" to "Independence Day", "12-24" to "Christmas Eve", "12-25" to "Christmas Day", "12-26" to "Second Day of Christmas",
    )
    val SUNSETS = listOf("16:10", "16:55", "17:45", "19:30", "20:15", "20:50", "20:40", "20:00", "19:00", "17:55", "16:05", "15:45")
    val LIT_AFTER_DARK = setOf("rynek", "florian", "grodzka", "szeroka", "placnowy", "bulwary", "bernatek", "smok", "wawel")
    val LANDMARKS = listOf(
        "rynek" to "Main Square", "florian" to "Florian Gate", "wawel" to "Wawel", "szeroka" to "Kazimierz", "placnowy" to "Plac Nowy",
        "schindler" to "Schindler's Factory", "ghetto" to "Podgórze", "blonia" to "Błonia", "nowahuta" to "Nowa Huta", "wieliczka" to "Wieliczka",
    )
    val FILTERS = listOf(
        "free" to "Free to see", "all" to "All", "sight" to "Sights", "museum" to "Museums", "food" to "Eat",
        "drinks" to "Bars", "coffee" to "Coffee & sweets", "park" to "Parks & views",
    )

    // Every place once: first version from the themes, then food.
    val PLACES: List<Place> = run {
        val m = LinkedHashMap<String, Place>()
        THEMES.forEach { t -> t.stops.forEach { s -> if (!m.containsKey(s.id)) m[s.id] = s } }
        FOOD.forEach { m[it.id] = it }
        m.values.toList()
    }
    val BY_ID = PLACES.associateBy { it.id }

    fun catOf(p: Place): String = when {
        p.kinds.isEmpty() -> CAT[p.id] ?: "sight"
        "lunch" in p.kinds || "dinner" in p.kinds -> "food"
        "bar" in p.kinds -> "drinks"
        else -> "coffee"
    }
    fun isFoodCat(c: String) = c == "food" || c == "coffee" || c == "drinks"
    fun isFree(p: Place) = p.id in FREE
    fun money(n: Int) = "$n $CUR"
}
