package com.laur.krakowtrip

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

data class PlaceInfo(val extract: String, val page: String, val photos: List<File>)

/**
 * Photos and Wikipedia text for each place. The first time a place is opened they are downloaded
 * and saved in the app's own storage, so after that they show without internet.
 */
class Photos(private val ctx: Context, private val db: TripDb) {
    private val dir = File(ctx.filesDir, "photos").apply { mkdirs() }
    private val locks = HashMap<String, Mutex>()
    private val mem = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    private fun lock(id: String) = synchronized(locks) { locks.getOrPut(id) { Mutex() } }

    private fun saved(id: String): PlaceInfo? {
        val files = db.query("SELECT file FROM photos WHERE id=? ORDER BY idx", arrayOf(id)) { File(dir, it.getString(0)) }.filter { it.exists() }
        val info = db.query("SELECT extract, page FROM info WHERE id=?", arrayOf(id)) { it.getString(0) to it.getString(1) }.firstOrNull()
        if (files.isEmpty() && info == null) return null
        return PlaceInfo(info?.first ?: "", info?.second ?: "", files)
    }

    fun cached(id: String): PlaceInfo? = saved(id)

    /** Number of places that already have photos saved on the phone. */
    fun savedPlaces(): Int = db.query("SELECT COUNT(DISTINCT id) FROM photos") { it.getInt(0) }.firstOrNull() ?: 0

    suspend fun load(p: Place): PlaceInfo = withContext(Dispatchers.IO) {
        lock(p.id).withLock {
            val have = saved(p.id)
            if (have != null && have.photos.isNotEmpty()) return@withLock have
            val text = if (p.isFood) null else runCatching { fetchText(p) }.getOrNull()
            val urls = runCatching { if (p.isFood) foodPhotoUrls(p) else sightPhotoUrls(p) }.getOrDefault(emptyList())
            val files = ArrayList<File>()
            urls.forEachIndexed { k, u ->
                val f = File(dir, "${p.id}_$k.jpg")
                if (runCatching { download(u, f) }.isSuccess) {
                    db.put("photos", ContentValues().apply { put("id", p.id); put("idx", files.size); put("file", f.name) })
                    files.add(f)
                }
            }
            if (text != null) db.put("info", ContentValues().apply { put("id", p.id); put("extract", text.first); put("page", text.second) })
            saved(p.id) ?: PlaceInfo(text?.first ?: "", text?.second ?: "", files)
        }
    }

    suspend fun bitmap(f: File, maxW: Int): Bitmap? = withContext(Dispatchers.IO) {
        mem.get(f.path)?.let { return@withContext it }
        runCatching {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= maxW) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        }.getOrNull()?.also { mem.put(f.path, it) }
    }

    // ---------- network ----------

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "KrakowTrip/2.0 (personal Android trip app)")
        c.connectTimeout = 12000; c.readTimeout = 15000
        try {
            if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun download(url: String, to: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "KrakowTrip/2.0 (personal Android trip app)")
        c.connectTimeout = 12000; c.readTimeout = 20000
        try {
            if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
            val tmp = File(to.path + ".part")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (!tmp.renameTo(to)) throw RuntimeException("rename failed")
        } finally { c.disconnect() }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /** Lead image of each place's Wikipedia article, found while fetching its summary. */
    private val leadImage = HashMap<String, String>()

    private fun fetchText(p: Place): Pair<String, String>? {
        Trip.WIKI[p.id]?.let { t ->
            val j = JSONObject(get("https://en.wikipedia.org/api/rest_v1/page/summary/" + enc(t)))
            j.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }?.let {
                leadImage[p.id] = it.replace(Regex("/\\d+px-"), "/800px-")
            }
            val ex = j.optString("extract")
            if (ex.isNotBlank() && j.optString("type") != "disambiguation") {
                val page = j.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page") ?: ""
                return ex to page
            }
        }
        val r = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=1&gsrsearch=" +
            enc(p.name + " " + Trip.CITY) + "&prop=extracts|info&exintro=1&explaintext=1&exsentences=3&inprop=url"))
        val pages = r.optJSONObject("query")?.optJSONObject("pages") ?: return null
        val pg = pages.optJSONObject(pages.keys().next()) ?: return null
        return pg.optString("extract") to pg.optString("fullurl")
    }

    private data class Hit(val title: String, val index: Int, val thumb: String)

    private fun commons(term: String, limit: Int = 20): List<Hit> {
        val r = JSONObject(get("https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=$limit&gsrsearch=" +
            enc("filetype:bitmap $term") + "&prop=imageinfo&iiprop=url|mime&iiurlwidth=800"))
        val pages = r.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val out = ArrayList<Hit>()
        pages.keys().forEach { k ->
            val pg = pages.getJSONObject(k)
            val ii = pg.optJSONArray("imageinfo")?.optJSONObject(0) ?: return@forEach
            if (!Regex("jpeg|png|webp").containsMatchIn(ii.optString("mime"))) return@forEach
            val u = ii.optString("thumburl").ifBlank { ii.optString("url") }
            if (u.isNotBlank()) out.add(Hit(pg.optString("title"), pg.optInt("index", 999), u))
        }
        return out.sortedBy { it.index }
    }

    private val junk = Regex("map|plan|karte|logo|coat|wappen|herb|diagram|menu|receipt", RegexOption.IGNORE_CASE)

    /** The Wikipedia article's own photo first (almost always the landmark itself), then Commons search results. */
    private fun sightPhotoUrls(p: Place): List<String> {
        val term = Trip.COMMONS[p.id] ?: (p.name + " " + Trip.CITY)
        val found = runCatching { commons(term, 14) }.getOrDefault(emptyList()).filter { !junk.containsMatchIn(it.title) }.map { it.thumb }
        val lead = leadImage[p.id]
        val leadName = lead?.substringAfterLast("/")?.substringAfter("px-")
        val rest = found.filter { leadName == null || !it.contains(leadName) }
        return (listOfNotNull(lead) + rest).take(6)
    }

    private fun plain(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").replace("ł", "l").replace("Ł", "L").lowercase()

    private val generic = setOf("cafe", "caffe", "the", "and", "pod", "bar", "mleczny", "books", "lounge", "chocolate", "plac", "nowy", "cloth", "hall", "pierogarnia", "krakow", "wodka", "restaurant")
    private val inside = Regex("interior|inside|wnetrz|sala|dining|counter|bar room", RegexOption.IGNORE_CASE)

    /** Up to 5 photos of a restaurant, inside shots first. */
    private fun foodPhotoUrls(p: Place): List<String> {
        val nm = p.name.substringBefore(",")
        val toks = plain(nm).split(Regex("[^a-z0-9]+")).filter { it.length >= 4 && it !in generic }
        val seen = HashSet<String>()
        val hits = listOf("$nm ${Trip.CITY} wnętrze", "$nm interior", "$nm ${Trip.CITY}").flatMap { runCatching { commons(it) }.getOrDefault(emptyList()) }
            .filter { h ->
                val t = plain(h.title)
                !junk.containsMatchIn(h.title) && (toks.isEmpty() || toks.any { t.contains(it) }) && seen.add(h.title)
            }
        return hits.sortedByDescending { inside.containsMatchIn(plain(it.title)) }.map { it.thumb }.take(5)
    }
}
