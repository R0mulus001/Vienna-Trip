package com.laur.krakowtrip

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** Everything the app remembers lives in one SQLite database on the phone. */
class TripDb(ctx: Context) : SQLiteOpenHelper(ctx, "trip.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE visited(id TEXT PRIMARY KEY, at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE notes(id TEXT PRIMARY KEY, text TEXT NOT NULL, stars INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE photos(id TEXT NOT NULL, idx INTEGER NOT NULL, file TEXT NOT NULL, PRIMARY KEY(id, idx))")
        db.execSQL("CREATE TABLE info(id TEXT PRIMARY KEY, extract TEXT NOT NULL, page TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun <T> query(sql: String, args: Array<String> = emptyArray(), row: (android.database.Cursor) -> T): List<T> =
        readableDatabase.rawQuery(sql, args).use { c -> buildList { while (c.moveToNext()) add(row(c)) } }

    fun put(table: String, values: ContentValues) {
        writableDatabase.insertWithOnConflict(table, null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun delete(table: String, id: String) {
        writableDatabase.delete(table, "id=?", arrayOf(id))
    }

    fun kvGet(k: String): String? = query("SELECT v FROM kv WHERE k=?", arrayOf(k)) { it.getString(0) }.firstOrNull()
    fun kvPut(k: String, v: String) = put("kv", ContentValues().apply { put("k", k); put("v", v) })
}

data class Note(val text: String = "", val stars: Int = 0) {
    val isEmpty get() = text.isBlank() && stars == 0
}

/** App state backed by the database. Compose redraws whenever these change. */
class TripState(val db: TripDb) {
    val visited = mutableStateMapOf<String, Long>()
    val notes = mutableStateMapOf<String, Note>()
    val themeByDay = mutableStateMapOf<String, String>()
    val orderByPlan = mutableStateMapOf<String, List<String>>()

    var tab by mutableStateOf(db.kvGet("tab") ?: "near"); private set
    var filter by mutableStateOf(db.kvGet("filter") ?: "free"); private set
    var manual by mutableStateOf(db.kvGet("manual") ?: ""); private set
    var showSeen by mutableStateOf(db.kvGet("showSeen") == "1"); private set
    var start by mutableStateOf(db.kvGet("start") ?: ""); private set
    var len by mutableStateOf(db.kvGet("len")?.toIntOrNull() ?: 4); private set
    var day by mutableStateOf(db.kvGet("day") ?: ""); private set
    var themeMode by mutableStateOf(db.kvGet("themeMode") ?: "auto"); private set

    init {
        db.query("SELECT id, at FROM visited") { it.getString(0) to it.getLong(1) }.forEach { visited[it.first] = it.second }
        db.query("SELECT id, text, stars FROM notes") { it.getString(0) to Note(it.getString(1), it.getInt(2)) }.forEach { notes[it.first] = it.second }
        db.kvGet("themes")?.let { s -> runCatching { val o = JSONObject(s); o.keys().forEach { themeByDay[it] = o.getString(it) } } }
        db.kvGet("orders")?.let { s ->
            runCatching {
                val o = JSONObject(s)
                o.keys().forEach { k -> val a = o.getJSONArray(k); orderByPlan[k] = List(a.length()) { a.getString(it) } }
            }
        }
    }

    fun isSeen(id: String) = visited.containsKey(id)
    fun toggleSeen(id: String) {
        if (visited.remove(id) != null) db.delete("visited", id)
        else {
            val now = System.currentTimeMillis()
            visited[id] = now
            db.put("visited", ContentValues().apply { put("id", id); put("at", now) })
        }
    }

    fun note(id: String) = notes[id] ?: Note()
    fun setNote(id: String, n: Note) {
        if (n.isEmpty) { notes.remove(id); db.delete("notes", id) }
        else { notes[id] = n; db.put("notes", ContentValues().apply { put("id", id); put("text", n.text); put("stars", n.stars) }) }
    }

    fun setTab(v: String) { tab = v; db.kvPut("tab", v) }
    fun setFilter(v: String) { filter = v; db.kvPut("filter", v) }
    fun setManual(v: String) { manual = v; db.kvPut("manual", v) }
    fun setShowSeen(v: Boolean) { showSeen = v; db.kvPut("showSeen", if (v) "1" else "0") }
    fun setStart(v: String) { start = v; db.kvPut("start", v) }
    fun setLen(v: Int) { len = v; db.kvPut("len", v.toString()) }
    fun setDay(v: String) { day = v; db.kvPut("day", v) }
    fun setThemeMode(v: String) { themeMode = v; db.kvPut("themeMode", v) }

    fun setTheme(dayKey: String, theme: String) {
        themeByDay[dayKey] = theme
        db.kvPut("themes", JSONObject(themeByDay.toMap()).toString())
    }

    fun setOrder(planKey: String, ids: List<String>) {
        orderByPlan[planKey] = ids
        val o = JSONObject(); orderByPlan.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        db.kvPut("orders", o.toString())
    }
}
