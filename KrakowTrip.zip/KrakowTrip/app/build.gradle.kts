plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.laur.krakowtrip"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.laur.krakowtrip"
        minSdk = 26
        targetSdk = 34
        versionCode = 11
        versionName = "2.6"
    }

    signingConfigs {
        // Key lives in app/krakow.p12, encrypted (AES-256). Its password is only in the
        // GitHub secret SIGNING_PASSWORD, so the key file is useless to anyone else.
        create("trip") {
            val pw = System.getenv("SIGNING_PASSWORD")
                ?: error("SIGNING_PASSWORD is not set (add it under repo Settings > Secrets and variables > Actions)")
            storeFile = file("krakow.p12")
            storeType = "PKCS12"
            storePassword = pw
            keyAlias = "app"
            keyPassword = pw
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("trip")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("trip")
        }
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
