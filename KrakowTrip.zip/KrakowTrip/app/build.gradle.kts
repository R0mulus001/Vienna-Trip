plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.laur.krakowtrip"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.laur.krakowtrip"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.1"
    }

    signingConfigs {
        // Fixed key so each new build installs as an update over the previous one.
        create("trip") {
            storeFile = file("krakow.keystore")
            storePassword = "viennatrip"
            keyAlias = "vienna"
            keyPassword = "viennatrip"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("trip")
        }
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the release APK installs without extra setup.
            signingConfig = signingConfigs.getByName("trip")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
