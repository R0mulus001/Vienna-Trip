# Krakow Trip (Android)

Kraków city guide with live GPS distance, day plans, food and bar spots. Set your trip dates in the Day plans tab.

Built by GitHub Actions from `KrakowTrip.zip` in the repo root (workflow "Build Krakow APK").
Everything the app shows is in `app/src/main/assets/index.html`.
