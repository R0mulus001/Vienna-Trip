# Krakow Trip (Android, native)

Native Kotlin / Jetpack Compose app. Kraków city guide with live GPS distance, day plans, food and bar spots,
restaurant prices and menus, and a Visited tab.

Everything is stored on the phone in an SQLite database (`trip.db`): visited places with date and time,
day-plan themes and route order, notes and star ratings per place, and Wikipedia text and photos once a place
has been opened (photos are saved in the app's files folder, so they work offline).

- Data (places, plans, prices): `app/src/main/java/com/laur/krakowtrip/Data.kt`
- Storage: `Store.kt`, photos: `Photos.kt`, screens: `Ui.kt` and `Sheet.kt`

Built by GitHub Actions from `KrakowTrip.zip` in the repo root (workflow "Build Krakow APK").
The fonts (Fraunces, Work Sans) are downloaded from Google Fonts during the build.
