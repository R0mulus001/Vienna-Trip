plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.laur.viennatrip"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.laur.viennatrip"
        minSdk = 26
        targetSdk = 34
        versionCode = 9
        versionName = "2.7"
    }

    signingConfigs {
        // Fixed key so each new build installs as an update over the previous one.
        create("trip") {
            storeFile = file("vienna.keystore")
            storePassword = "viennatrip"
            keyAlias = "vienna"
            keyPassword = "viennatrip"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("trip")
        }
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the release APK installs without extra setup.
            signingConfig = signingConfigs.getByName("trip")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
