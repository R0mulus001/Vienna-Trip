# Vienna Trip (Android)

Your Vienna itinerary app (31 Oct to 3 Nov), packaged for Android, with live GPS distance to your next stop.

## Build in Android Studio
1. Unzip and open the `ViennaTrip` folder with **File > Open**.
2. Let Gradle sync finish (first time downloads the Android tools).
3. **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The APK is at `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install it
   (allow "Install unknown apps" for your file manager when asked).

Or plug the phone in with USB debugging on and press **Run**.

## Build on GitHub instead
Push this folder to a new GitHub repository. The **Build APK** workflow runs automatically;
download the APK from the run's **Artifacts** section.

## Editing the itinerary
Everything the app shows is in `app/src/main/assets/index.html`.
