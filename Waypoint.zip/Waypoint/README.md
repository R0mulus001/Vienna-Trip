# Waypoint (Android, native)

One app for all trip cities (Kraków, Vienna, Milan). Start screen: pick a city. Inside a city: Nearby, Day plans
and Visited, with that city's flag and colours. Kotlin / Jetpack Compose.

- City data (places, plans, prices, holidays, tips, colours): `app/src/main/assets/cities/<city>.json`.
  Adding a city = adding one JSON file and its key to `City.ORDER` in `Data.kt`.
- Each city has its own database on the phone (`city_<key>.db`): visited places with date and time, day plans,
  notes and stars. Photos and Wikipedia text are saved in `files/photos/<key>/` after the first look (or all at once
  with "Download all"), so they work offline.

Built by GitHub Actions from `Waypoint.zip` (workflow "Build Waypoint APK"). Fonts are downloaded during the build.
