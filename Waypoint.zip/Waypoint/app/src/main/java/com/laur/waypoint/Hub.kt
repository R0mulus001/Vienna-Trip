package com.laur.waypoint

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Each city's saved data and photos, opened the first time they're needed. */
class CityStores(private val ctx: Context, val cities: List<City>) {
    private val states = HashMap<String, TripState>()
    private val photos = HashMap<String, Photos>()
    fun state(c: City) = states.getOrPut(c.key) { TripState(TripDb(ctx, c.key)) }
    fun photos(c: City) = photos.getOrPut(c.key) { Photos(ctx, state(c).db, c) }
}

private const val HUB_BAR = 0xFF1A4FA0

@Composable
fun WaypointApp(
    stores: CityStores, gps: LatLng?, locationOn: Boolean,
    requestLocation: () -> Unit, openUrl: (String) -> Unit, setBarColor: (Long) -> Unit,
) {
    val sysDark = isSystemInDarkTheme()
    val dark = when (Hub.themeMode) { "light" -> false; "dark" -> true; else -> sysDark }
    val city = stores.cities.firstOrNull { it.key == Hub.city }?.takeIf { Hub.onboarded }
    if (city != null) Trip.city = city
    val pal = palFor(city, dark)
    SideEffect { setBarColor(city?.accent?.bar ?: HUB_BAR) }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        CompositionLocalProvider(LocalPal provides pal) {
            when {
                !Hub.onboarded -> HubWelcome(stores, locationOn, requestLocation)
                city == null -> HubScreen(stores)
                else -> TripApp(stores.state(city), stores.photos(city), gps, locationOn, requestLocation, openUrl) { Hub.open("") }
            }
        }
    }
}

@Composable
fun BrandMark(size: Int = 34) {
    val c = LocalPal.current
    Box(Modifier.size(size.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
        Icon(PinIcon, null, tint = c.accentFg, modifier = Modifier.size((size * 0.62f).dp))
    }
}

@Composable
fun HubScreen(stores: CityStores) {
    val c = LocalPal.current
    // Visits across every city, newest first, for the travel diary.
    val diary = stores.cities.flatMap { city ->
        val st = stores.state(city)
        st.visited.entries.mapNotNull { (id, at) -> city.byId[id]?.let { Triple(city, it, at) } }
    }.sortedByDescending { it.third }

    LazyColumn(Modifier.fillMaxSize().background(c.bg), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrandMark()
                T("Waypoint", 27.sp, FontWeight.SemiBold, family = Fonts.display, modifier = Modifier.weight(1f))
                ThemePill()
            }
        }
        item {
            Column(Modifier.padding(top = 8.dp)) {
                T("Where are you going?", 22.sp, FontWeight.SemiBold, family = Fonts.display)
                T("Pick a city. Everything you save stays with that city.", 14.sp, color = c.muted)
            }
        }
        items(stores.cities, key = { it.key }) { city -> CityCard(stores, city) }
        item {
            Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                T("Your travel diary", 20.sp, FontWeight.SemiBold, family = Fonts.display)
                T(if (diary.isEmpty()) "Places you visit in any city show up here." else "${diary.size} place" + (if (diary.size == 1) "" else "s") +
                    " visited in ${diary.map { it.first.key }.toSet().size} cit" + (if (diary.map { it.first.key }.toSet().size == 1) "y" else "ies"), 14.sp, color = c.muted)
            }
        }
        items(diary.take(12), key = { "d-" + it.first.key + it.second.id }) { (city, p, at) ->
            Card(Modifier.clickable { Hub.open(city.key); stores.state(city).setTab("visited") }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Flag(27, 18, city.flag)
                    Column(Modifier.weight(1f)) {
                        T(p.name, 15.5.sp, FontWeight.SemiBold, maxLines = 1)
                        T(city.name + " · " + visitedWhen(at, city), 13.sp, color = c.muted)
                    }
                    Stars(stores.state(city).note(p.id).stars)
                }
            }
        }
        item { T("More cities can be added: each one is a single data file in the app.", 12.5.sp, color = c.muted, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
private fun CityCard(stores: CityStores, city: City) {
    val c = LocalPal.current
    val st = stores.state(city)
    val accent = androidx.compose.ui.graphics.Color(if (c.dark) city.accent.dark else city.accent.light)
    val dates = if (st.start.isBlank()) "Trip dates not set" else tripLabel(tripDays(st.start, st.len))
    val visited = st.visited.size
    Card(Modifier.clickable { Hub.open(city.key) }) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Flag(48, 32, city.flag)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                T(city.name, 21.sp, FontWeight.SemiBold, family = Fonts.display)
                T(city.country + " · " + city.tagline, 13.5.sp, color = c.muted, maxLines = 1)
                T(dates + (if (visited > 0) " · $visited visited" else ""), 13.5.sp, FontWeight.SemiBold, accent)
            }
            T("›", 26.sp, color = c.muted)
        }
    }
}

@Composable
fun ThemePill() {
    val c = LocalPal.current
    val label = when (Hub.themeMode) { "light" -> "Light"; "dark" -> "Dark"; else -> "Auto" }
    Box(Modifier.clip(CircleShape).background(c.surface).border(1.dp, c.line, CircleShape)
        .clickable { Hub.setThemeMode(when (Hub.themeMode) { "auto" -> "light"; "light" -> "dark"; else -> "auto" }) }
        .padding(horizontal = 12.dp, vertical = 8.dp)) {
        T(label, 13.sp, FontWeight.SemiBold)
    }
}
