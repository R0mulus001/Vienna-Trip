package com.laur.waypoint

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

data class PlaceInfo(val extract: String, val page: String, val photos: List<File>)

private class Busy : RuntimeException("busy")

/**
 * Photos and Wikipedia text for each place. The first time a place is opened (or with Download all) they are
 * downloaded and saved in the app's own storage, so after that they show without internet.
 *
 * A place counts as "done" once its lookup finished without network errors, even if it has no photos online,
 * so Download all can tell "nothing to download" apart from "failed, try again".
 */
class Photos(private val ctx: Context, private val db: TripDb, private val city: City) {
    private val dir = File(ctx.filesDir, "photos/${city.key}").apply { mkdirs() }
    private val locks = HashMap<String, Mutex>()
    private val mem = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    init {
        db.writableDatabase.execSQL("CREATE TABLE IF NOT EXISTS checked(id TEXT PRIMARY KEY)")
        // Photo choice changed in version 2 (photos from each place's own article). Old picks are cleared once.
        if (db.kvGet("photoVer") != "2") {
            db.writableDatabase.execSQL("DELETE FROM photos")
            db.writableDatabase.execSQL("DELETE FROM checked")
            dir.listFiles()?.forEach { it.delete() }
            db.kvPut("photoVer", "2")
        }
    }

    private fun log(p: Place, what: String, e: Throwable?) =
        android.util.Log.w("Waypoint", "photos ${city.key}/${p.id} $what failed: ${e?.javaClass?.simpleName} ${e?.message}")

    private fun lock(id: String) = synchronized(locks) { locks.getOrPut(id) { Mutex() } }

    private fun saved(id: String): PlaceInfo? {
        val files = db.query("SELECT file FROM photos WHERE id=? ORDER BY idx", arrayOf(id)) { File(dir, it.getString(0)) }.filter { it.exists() }
        val info = db.query("SELECT extract, page FROM info WHERE id=?", arrayOf(id)) { it.getString(0) to it.getString(1) }.firstOrNull()
        if (files.isEmpty() && info == null) return null
        return PlaceInfo(info?.first ?: "", info?.second ?: "", files)
    }

    fun cached(id: String): PlaceInfo? = saved(id)
    fun isDone(id: String) = db.query("SELECT 1 FROM checked WHERE id=?", arrayOf(id)) { 1 }.isNotEmpty()

    /** Places with at least one photo saved. */
    fun savedPlaces(): Int = db.query("SELECT COUNT(DISTINCT id) FROM photos") { it.getInt(0) }.firstOrNull() ?: 0
    /** Places whose lookup is finished (with or without photos). */
    fun donePlaces(): Int = db.query("SELECT COUNT(*) FROM checked") { it.getInt(0) }.firstOrNull() ?: 0

    suspend fun load(p: Place): PlaceInfo = withContext(Dispatchers.IO) {
        lock(p.id).withLock {
            val have = saved(p.id)
            if (isDone(p.id) && have != null) return@withLock have
            var textOk = true; var urlsOk = true
            val text = if (p.isFood) null else runCatching { fetchText(p) }.onFailure { textOk = false; log(p, "text", it) }.getOrNull()
            val urls = runCatching { if (p.isFood) foodPhotoUrls(p) else sightPhotoUrls(p) }.onFailure { urlsOk = false; log(p, "photo list", it) }.getOrDefault(emptyList())
            val already = have?.photos?.size ?: 0
            val files = ArrayList<File>(have?.photos ?: emptyList())
            if (already == 0) urls.forEachIndexed { k, u ->
                val f = File(dir, "${p.id}_$k.jpg")
                val r = runCatching { download(u, f) }
                if (r.isSuccess) {
                    db.put("photos", ContentValues().apply { put("id", p.id); put("idx", files.size); put("file", f.name) })
                    files.add(f)
                } else log(p, "image", r.exceptionOrNull())
                Thread.sleep(120) // be gentle with Wikimedia's servers
            }
            if (text != null) db.put("info", ContentValues().apply { put("id", p.id); put("extract", text.first); put("page", text.second) })
            // Done once the lookups worked and we have photos (a single failed image doesn't hold the place back).
            val ok = textOk && urlsOk && (files.isNotEmpty() || urls.isEmpty())
            if (ok) db.writableDatabase.execSQL("INSERT OR REPLACE INTO checked(id) VALUES(?)", arrayOf(p.id))
            saved(p.id) ?: PlaceInfo(text?.first ?: "", text?.second ?: "", files)
        }
    }

    suspend fun bitmap(f: File, maxW: Int): Bitmap? = withContext(Dispatchers.IO) {
        mem.get(f.path)?.let { return@withContext it }
        runCatching {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= maxW) s *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        }.getOrNull()?.also { mem.put(f.path, it) }
    }

    // ---------- network, with retries when the server is busy ----------

    private fun <T> retry(block: () -> T): T {
        var last: Exception? = null
        repeat(4) { attempt ->
            if (attempt > 0) Thread.sleep(2000L * attempt * attempt)
            try { return block() } catch (e: Busy) { last = e; android.util.Log.w("Waypoint", "busy, retry ${attempt + 1}") }
            catch (e: SocketTimeoutException) { last = e; android.util.Log.w("Waypoint", "timeout, retry ${attempt + 1}") }
        }
        throw last ?: RuntimeException("failed")
    }

    private fun open(url: String, readTimeout: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "Waypoint/1.0 (personal Android city guide)")
        c.connectTimeout = 12000; c.readTimeout = readTimeout
        val code = c.responseCode
        if (code == 429 || code >= 500) { c.disconnect(); android.util.Log.w("Waypoint", "HTTP $code ${url.take(90)}"); throw Busy() }
        if (code !in 200..299) { c.disconnect(); throw RuntimeException("HTTP $code") }
        return c
    }

    private fun get(url: String): String = retry {
        val c = open(url, 15000)
        try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun download(url: String, to: File) = retry {
        val c = open(url, 25000)
        try {
            val tmp = File(to.path + ".part")
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (tmp.length() < 2000 || !tmp.renameTo(to)) { tmp.delete(); throw RuntimeException("bad image") }
        } finally { c.disconnect() }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun firstPage(r: JSONObject): JSONObject? {
        val pages = r.optJSONObject("query")?.optJSONObject("pages") ?: return null
        val it = pages.keys(); return if (it.hasNext()) pages.optJSONObject(it.next()) else null
    }

    private fun fetchText(p: Place): Pair<String, String>? {
        city.wiki[p.id]?.let { t ->
            val j = JSONObject(get("https://en.wikipedia.org/api/rest_v1/page/summary/" + enc(t)))
            val ex = j.optString("extract")
            if (ex.isNotBlank() && j.optString("type") != "disambiguation") {
                val page = j.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page") ?: ""
                return ex to page
            }
        }
        val pg = firstPage(JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=1&gsrsearch=" +
            enc(p.name + " " + city.cityLocal) + "&prop=extracts|info&exintro=1&explaintext=1&exsentences=3&inprop=url"))) ?: return null
        return pg.optString("extract") to pg.optString("fullurl")
    }

    // ---------- choosing photos ----------

    private data class Img(val title: String, val thumb: String)

    /** Drawings, symbols and documents rather than photos of the place. */
    private val junk = Regex("map|plan\\b|plan_|karte|logo|coat|wappen|herb\\b|diagram|menu|receipt|flag|icon|symbol|signature|locator|seal|emblem|" +
        "stamp|banknote|coin|chart|graph|poster|cover|award|medal|scheme|location|commons-|wiki|button|arrow|sketch|drawing|engraving|lithograph",
        RegexOption.IGNORE_CASE)

    private fun usable(title: String, mime: String, w: Int, h: Int): Boolean =
        Regex("jpeg|webp").containsMatchIn(mime) && w >= 600 && h >= 400 && w.toFloat() / h in 0.6f..2.6f && !junk.containsMatchIn(title)

    /** The photo at the top of the place's Wikipedia article: almost always the landmark itself. */
    private fun leadImage(title: String): String? {
        val pg = firstPage(JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&format=json&redirects=1&prop=pageimages&piprop=thumbnail&pithumbsize=960&titles=" +
            enc(title.replace('_', ' '))))) ?: return null
        return pg.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }
    }

    /** Photos used inside the place's own Wikipedia article: chosen by editors, so they show the right place. */
    private fun articleImages(title: String): List<Img> {
        val r = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&format=json&redirects=1&generator=images&gimlimit=60" +
            "&prop=imageinfo&iiprop=url%7Cmime%7Csize&iiurlwidth=960&titles=" + enc(title.replace('_', ' '))))
        val pages = r.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val out = ArrayList<Img>()
        pages.keys().forEach { k ->
            val pg = pages.getJSONObject(k)
            val ii = pg.optJSONArray("imageinfo")?.optJSONObject(0) ?: return@forEach
            val t = pg.optString("title")
            if (usable(t, ii.optString("mime"), ii.optInt("width"), ii.optInt("height")))
                out.add(Img(t, ii.optString("thumburl").ifBlank { ii.optString("url") }))
        }
        return out
    }

    private fun commons(term: String, limit: Int = 20): List<Img> {
        val r = JSONObject(get("https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=$limit&gsrsearch=" +
            enc("filetype:bitmap $term") + "&prop=imageinfo&iiprop=url%7Cmime%7Csize&iiurlwidth=960"))
        val pages = r.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        return pages.keys().asSequence().map { pages.getJSONObject(it) }.sortedBy { it.optInt("index", 999) }.mapNotNull { pg ->
            val ii = pg.optJSONArray("imageinfo")?.optJSONObject(0) ?: return@mapNotNull null
            val t = pg.optString("title")
            if (usable(t, ii.optString("mime"), ii.optInt("width"), ii.optInt("height"))) Img(t, ii.optString("thumburl").ifBlank { ii.optString("url") }) else null
        }.toList()
    }

    private fun plain(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").replace("ł", "l").replace("Ł", "L").lowercase()
    private fun fileName(url: String) = plain(url.substringAfterLast("/").substringAfter("px-"))

    private val generic = setOf("cafe", "caffe", "the", "and", "pod", "bar", "mleczny", "books", "lounge", "chocolate", "plac", "nowy", "cloth", "hall",
        "pierogarnia", "krakow", "wodka", "restaurant", "restaurante", "gasthaus", "zum", "zur", "der", "die", "das", "wien", "vienna", "stalls", "food",
        "ristorante", "trattoria", "pizzeria", "pasticceria", "milano", "milan", "antica", "terrazza", "della", "dei", "del", "schwarzen", "weissen",
        "church", "palace", "square", "museum", "park", "street", "bridge", "tower", "gate", "house", "garden", "gardens", "castle", "basilica",
        "cathedral", "national", "city", "old", "new", "saint", "royal", "main", "great", "grand")

    /** Distinctive words of a name ("Cloth Hall (Sukiennice)" -> sukiennice). Pictures from search must contain one. */
    private fun tokens(name: String) = plain(name).split(Regex("[^a-z0-9]+")).filter { it.length >= 4 && it !in generic }.toSet()

    private fun matches(title: String, toks: Set<String>) = toks.isNotEmpty() && toks.any { plain(title).contains(it) }

    /** Up to 6 photos of a sight: the article's own lead photo, then other photos from that article, then strict search results. */
    private fun sightPhotoUrls(p: Place): List<String> {
        val title = city.wiki[p.id]
        val picked = LinkedHashMap<String, String>() // file name -> url
        fun add(u: String) { val n = fileName(u); if (n.isNotBlank() && !picked.containsKey(n)) picked[n] = u }
        if (title != null) {
            leadImage(title)?.let(::add)
            articleImages(title).forEach { add(it.thumb) }
        }
        if (picked.size < 3) {
            val toks = tokens(p.name)
            val term = city.commons[p.id] ?: (p.name.substringBefore(" (") + " " + city.cityLocal)
            commons(term, 14).filter { matches(it.title, toks) || city.commons.containsKey(p.id) && matches(it.title, tokens(term)) }.forEach { add(it.thumb) }
        }
        return picked.values.take(6)
    }

    private val inside = Regex("interior|inside|innen|innenraum|interno|wnetrz|sala|saal|dining|counter|theke|bancone|bar room", RegexOption.IGNORE_CASE)

    /** Up to 5 photos of a restaurant, inside shots first. Only pictures whose file name contains the place's own name. */
    private fun foodPhotoUrls(p: Place): List<String> {
        val nm = p.name.substringBefore(",")
        val toks = tokens(nm)
        if (toks.isEmpty()) return emptyList()
        val seen = HashSet<String>()
        val hits = listOf("$nm ${city.cityLocal} ${city.inner}", "$nm interior", "$nm ${city.cityLocal}").flatMap { commons(it) }
            .filter { matches(it.title, toks) && seen.add(it.title) }
        return hits.sortedByDescending { inside.containsMatchIn(plain(it.title)) }.map { it.thumb }.take(5)
    }
}

/** Download all for one city. Lives as long as the app, so it keeps going when you leave the city screen. */
class Downloader(private val photos: Photos, private val city: City, private val scope: CoroutineScope) {
    var running by mutableStateOf(false); private set
    var done by mutableIntStateOf(0); private set
    var total by mutableIntStateOf(0); private set
    var withPhotos by mutableIntStateOf(photos.savedPlaces()); private set
    var finished by mutableIntStateOf(photos.donePlaces()); private set

    val places get() = city.places.size
    /** Places whose lookup failed (busy server, no signal) and should be tried again. */
    val failed get() = (places - finished).coerceAtLeast(0)

    fun refresh() { withPhotos = photos.savedPlaces(); finished = photos.donePlaces() }

    fun start() {
        if (running) return
        val todo = city.places.filter { !photos.isDone(it.id) }
        if (todo.isEmpty()) { refresh(); return }
        running = true; done = 0; total = todo.size
        scope.launch {
            // Three places at a time: much faster, still gentle on Wikimedia.
            val gate = kotlinx.coroutines.sync.Semaphore(3)
            kotlinx.coroutines.coroutineScope {
                todo.forEach { p ->
                    launch {
                        gate.acquire()
                        try { runCatching { photos.load(p) } } finally { gate.release() }
                        done++
                        if (done % 5 == 0) refresh()
                    }
                }
            }
            // One more, slower pass for anything that failed (usually a busy server).
            val again = city.places.filter { !photos.isDone(it.id) }
            if (again.isNotEmpty()) {
                kotlinx.coroutines.delay(15_000)
                again.forEach { p -> runCatching { photos.load(p) }; refresh() }
            }
            refresh()
            running = false
        }
    }
}
